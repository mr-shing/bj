(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_f9831063._.js",
  "static/chunks/node_modules_three_build_three_module_7d17ea5c.js",
  "static/chunks/node_modules_next_cab4629d._.js",
  "static/chunks/node_modules_zod_lib_index_mjs_ee760afb._.js",
  "static/chunks/node_modules_709daeac._.js"
],
    source: "dynamic"
});
