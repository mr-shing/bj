(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_acfff5e2._.js",
  "static/chunks/src_ead2b2b2._.js"
],
    source: "dynamic"
});
