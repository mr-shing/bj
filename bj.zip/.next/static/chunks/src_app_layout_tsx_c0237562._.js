(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_globals_b805903d.css",
  "static/chunks/node_modules_three_build_three_module_7d17ea5c.js",
  "static/chunks/node_modules_a9390255._.js",
  "static/chunks/src_d833e049._.js"
],
    source: "dynamic"
});
